def compute_sum(numbers):
    s = 0
    for n in numbers:
        s += n
    return s
